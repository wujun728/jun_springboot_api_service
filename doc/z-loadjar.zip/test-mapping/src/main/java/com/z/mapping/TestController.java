package com.z.mapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {
	@RequestMapping(value="/test2018_1")
	public String test2018_1(){
		return "test2018_1";
	}
	@RequestMapping(value="/test2018_2")
	public String test2018_2(){
		return "test2018_2";
	}
}
