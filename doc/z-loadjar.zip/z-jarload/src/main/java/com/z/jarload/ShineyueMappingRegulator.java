package com.z.jarload;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.impl.SLF4JLogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.util.ReflectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
/**
 * 将外部jar包中的requestmapping注册进spring容器中的工具类
 * @author zml
 *
 */
public class ShineyueMappingRegulator {
	
	private static final Log log = SLF4JLogFactory.getLog(ShineyueMappingRegulator.class);
	/**
	 * 添加requestmapping
	 * @param classmap class集合
	 * @param context spring容器上下文
	 */
	public void addMappingService(Map<String, ShineyueClassLoader> classmap,ApplicationContext  context) {
		//Map<String, PluginClassLoader> m = shineyueLoadJar.getClassMap();
		if (classmap.size() > 0) {
			for (Entry<String, ShineyueClassLoader> entry : classmap.entrySet()) {
				/*if(!entry.getKey().contains("service")){
					continue;
				}*/
				try {
					log.info("<<<<<<<<<<<<<<<<<<<<load jar :"+entry.getKey()+" mapping info >>>>>>>>>>>>>>>>>");
					ShineyueClassLoader pcl = entry.getValue();
					Map<String, Class<?>> m_service = pcl.loadJarMappingService();
					pcl.setMapping_info_list(this.addController(m_service,context));
				} catch (SecurityException e) {
					e.printStackTrace();
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				}

			}
		}

	}
	private List<RequestMappingInfo> addController(Map<String, Class<?>> classmap,ApplicationContext  Context){
		List<RequestMappingInfo> MappingInfo_list=new ArrayList<RequestMappingInfo>();
		RequestMappingHandlerMapping requestMappingHandlerMapping=Context.getBean(RequestMappingHandlerMapping.class);
		Method getMappingForMethod =ReflectionUtils.findMethod(RequestMappingHandlerMapping.class, "getMappingForMethod",Method.class,Class.class);
		getMappingForMethod.setAccessible(true);
		
		for (Entry<String, Class<?>> entry : classmap.entrySet()) {
			try {
				Method[] method_arr = entry.getValue().getMethods();
				for (Method m_d : method_arr) {
					if (m_d.getAnnotation(RequestMapping.class) != null) {
						RequestMappingInfo mapping_info = (RequestMappingInfo) getMappingForMethod.invoke(requestMappingHandlerMapping, m_d,entry.getValue());
						requestMappingHandlerMapping.registerMapping(mapping_info, entry.getValue().newInstance(),m_d);
						MappingInfo_list.add(mapping_info);
					}

				}

			} catch (SecurityException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			} catch (InstantiationException e) {
				e.printStackTrace();
			}
		}
		return MappingInfo_list;
	}
	/**
	 * 删除所有注册的requestmapping
	 * @param classmap
	 * @param context
	 */
	public void removeAllMappingService(Map<String, ShineyueClassLoader> classmap,ApplicationContext  context){
		if (classmap.size() > 0) {
			for (Entry<String, ShineyueClassLoader> entry : classmap.entrySet()) {
				try {
					ShineyueClassLoader pcl = entry.getValue();
					if(pcl.getMapping_info_list()!=null&pcl.getMapping_info_list().size()>0){
						this.removeMapping(pcl.getMapping_info_list(), context);
					}
				} catch (SecurityException e) {
					e.printStackTrace();
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				}

			}
		}
	}
	private void removeMapping(List<? extends Object> list,ApplicationContext  Context){
		RequestMappingHandlerMapping requestMappingHandlerMapping=Context.getBean(RequestMappingHandlerMapping.class);
		for(Object o:list){
			RequestMappingInfo info=(RequestMappingInfo) o;
			log.info("remove mapping :"+info.toString());
			requestMappingHandlerMapping.unregisterMapping(info);
		}
		
	}
}
