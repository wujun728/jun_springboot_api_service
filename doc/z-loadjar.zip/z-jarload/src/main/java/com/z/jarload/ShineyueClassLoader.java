package com.z.jarload;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.JarURLConnection;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLClassLoader;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.io.BufferedInputStream;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.impl.SLF4JLogFactory;
import org.springframework.web.bind.annotation.RestController;

/**
 * 插件类加载器，在插件目录中搜索jar包，并为发现的资源(jar)构造一个类加载器,将对应的jar添加到classpath中
 * @author strawxdl
 */
public class ShineyueClassLoader extends URLClassLoader {

	private List<JarURLConnection> cachedJarFiles = new ArrayList<JarURLConnection>();
	//private URL file_url;
	private static Log xlog = SLF4JLogFactory.getLog(ShineyueClassLoader.class);

	private List<String> service_list = new ArrayList<String>();
	//private List<String> bean_list = new ArrayList<String>();
	private List<? extends Object> mapping_info_list;
	private URL[] file_url_arr;

	public ShineyueClassLoader(URL[] resourceURL,URL[] file_url_arr) {
		super(new URL[] {}, findParentClassLoader());
		this.file_url_arr=file_url_arr;
		for(URL file_url:file_url_arr){
			this.addURLFile(file_url);
		}
		
	}
    /**
     * 将指定的文件url添加到类加载器的classpath中去，并缓存jar connection，方便以后卸载jar
     * @param 一个可想类加载器的classpath中添加的文件url
     */
    public void addURLFile(URL fileURL) {
        try {
            // 打开并缓存文件url连接    
            URLConnection uc = fileURL.openConnection();
            if (uc instanceof JarURLConnection) {
                uc.setUseCaches(true);
                ((JarURLConnection) uc).getManifest();
                cachedJarFiles.add((JarURLConnection)uc);
            }
        } catch (Exception e) {
        	xlog.error("Failed to cache plugin JAR file: " + fileURL.toExternalForm(), e);
        }
        addURL(fileURL);
    }
    
    /**
     * 卸载jar包
     */
    public void unloadJarFiles() {
        for (JarURLConnection url : cachedJarFiles) {
            try {
            	xlog.warn("Unloading plugin JAR file " + url.getJarFile().getName());
                url.getJarFile().close();
                url=null;
            } catch (Exception e) {
            	xlog.error("Failed to unload JAR file", e);
            }
        }
        cachedJarFiles.clear();
        
        /*try {
        	Field field=ShineyueClassInstance.class.getDeclaredField("classMap");
    		field.setAccessible(true);
    		Map<String, URLClassLoader> m_URLClassLoader=(ConcurrentHashMap<String, URLClassLoader>)field.get(ShineyueClassInstance.getInstance());
    		for(String bean:bean_list){
    			m_URLClassLoader.remove(bean);
    			xlog.info("delete bean:"+bean+";");
    		}
    		
		} catch (Exception e) {
			xlog.error("error", e);
		}*/
        
    }

    /**
     * 定位基于当前上下文的父类加载器
     * @return 返回可用的父类加载器.
     */
    private static ClassLoader findParentClassLoader() {
        ClassLoader parent = ClassLoader.getSystemClassLoader();
        //parent = ClassLoader.getSystemClassLoader();
        return parent;
    }

	public Map<String, Class<?>> loadJarMappingService() {
		Map<String, Class<?>> m = new ConcurrentHashMap<String, Class<?>>();
		for (JarURLConnection url : cachedJarFiles) {
			try {
				File f = new File(url.getJarFileURL()
						.toURI());
				if(!f.getName().contains("-mapping")){
					continue;
				}
				InputStream isf = new FileInputStream(f);
				InputStream is = new BufferedInputStream(isf);
				ZipInputStream zis = new ZipInputStream(is);
				ZipEntry ze;
				while ((ze = zis.getNextEntry()) != null) {
					if (!ze.isDirectory()) {
						String classname = ze.getName().replace("/", ".").replace(".class", "");
						if (classname.contains("com.z.mapping")) {
							try {
								Class<?> c = Class.forName(classname, true,this);
								if (c.getAnnotation(RestController.class) != null) {
									m.put(c.getSimpleName().toLowerCase(), c);
									service_list.add(c.getSimpleName().toLowerCase());
									xlog.info("load class to map:" + classname+ " key:"+ c.getSimpleName().toLowerCase());
								}
							} catch (ClassNotFoundException e) {
								xlog.error("error",e);
							}
						}
					}
				}
				isf.close();
				is.close();
				zis.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (URISyntaxException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
		return m;
	}

	/*private ZipInputStream getJarInputStream(URI uri)throws FileNotFoundException {
		File f = new File(uri);
		InputStream isf = new FileInputStream(f);
		InputStream is = new BufferedInputStream(isf);
		ZipInputStream zis = new ZipInputStream(is);
		
		return zis;
	}*/


	public List<String> getService_list() {
		return service_list;
	}

	public List<? extends Object> getMapping_info_list() {
		return mapping_info_list;
	}

	public void setMapping_info_list(List<? extends Object> mapping_info_list) {
		this.mapping_info_list = mapping_info_list;
	}
	public void finalize(){
		for(URL file_url: this.file_url_arr){
			xlog.info(this.getClass().getName()+":"+file_url.toString()+" 已经被回收！！！！");
		}
	}
}