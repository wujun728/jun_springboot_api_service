package com.z.jarload;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.impl.SLF4JLogFactory;

public class ShineyueLoadJar {
	private Map<String, ShineyueClassLoader> JarMap=new ConcurrentHashMap<String, ShineyueClassLoader>();
	private String jarurl;
	private URL resourceURL;
	private static Log xlog = SLF4JLogFactory.getLog(ShineyueLoadJar.class);
	
	
	public void loadjarfile(){
		if(jarurl!=null||jarurl.equals("?")){
			loadjarfile(jarurl);
		}
		
	}
	public void loadjarfile(String url) {
		List<URL> f_j = getJarFile(url);
		if (f_j.size() > 0) {
			URL[] u_arr=new URL[f_j.size()];
			u_arr=f_j.toArray(u_arr);
			URL[] resourceURLArr= {this.resourceURL};
			if(JarMap.size()>0){
				removeJarAll();
			}
			JarMap.put(url, new ShineyueClassLoader(resourceURLArr,u_arr));
		}
	}
	public void removeJarAll(){
		for(Entry<String, ShineyueClassLoader> m:JarMap.entrySet()){
			m.getValue().unloadJarFiles();
		}
		JarMap.clear();
		xlog.info("集合中jar剩余:"+JarMap.size());
	}
	private List<URL> getJarFile(String url) {
		List<URL> l_u = new ArrayList<URL>();
		File file = new File(url);
		try {
			this.resourceURL=file.toURI().toURL();
		} catch (MalformedURLException e1) {
			e1.printStackTrace();
		}
		xlog.info("运行环境："+System.getProperty("os.name"));
		if (file.exists() && file.isDirectory()) {
			File[] f_arr = file.listFiles();
			for (File f : f_arr) {
				if (!f.isDirectory()) {
					xlog.info("load jar file:" + f.getName());
					if (f.getName().contains(".jar")) {
						String s_url;
						if(System.getProperty("os.name").toLowerCase().startsWith("win")){
							s_url = "jar:file:/" + url + "/" + f.getName()+ "!/";
						}else{
							 s_url = "jar:file:" + url + "/" + f.getName()+ "!/";
						}
						
						try {
							l_u.add(new URL(s_url));
						} catch (MalformedURLException e) {
							xlog.error("error url:" + s_url, e);
						}
					}
				}
			}
		} else {
			xlog.error("url exception:" + url);
		}
		return l_u;
	}


	public Map<String, ShineyueClassLoader> getClassLoaderMap() {
		return JarMap;
	}
	public String getJarurl() {
		return jarurl;
	}
	public void setJarurl(String jarurl) {
		this.jarurl = jarurl;
	}
	
}
