package com.z;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Service;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.impl.SLF4JLogFactory;
import com.z.jarload.ShineyueLoadJar;
import com.z.jarload.ShineyueMappingRegulator;
@Service
public class StartAppAfterRun implements ApplicationListener<ContextRefreshedEvent>{
	private ShineyueLoadJar shineyueLoadJar;
	private ApplicationContext Context;
	private static final Log log = SLF4JLogFactory.getLog(StartAppAfterRun.class);
	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		this.Context = event.getApplicationContext();
		this.shineyueLoadJar = this.Context.getBean(ShineyueLoadJar.class);//初始化载入需要被热加载的外部jar包
		if(shineyueLoadJar!=null){
			this.loadjar();
			ShineyueMappingRegulator shineyueMappingRegulator=this.Context.getBean(ShineyueMappingRegulator.class);
			shineyueMappingRegulator.addMappingService(this.shineyueLoadJar.getClassLoaderMap(), this.Context);
		}else{
			log.info("-------------<-------------------->--------------");
			log.info("shineyueLoadJar is null,not loaded outside jar");
			log.info("-------------<-------------------->--------------");
		}
	}
	private void loadjar(){
		
		this.shineyueLoadJar.loadjarfile();
	}
}
