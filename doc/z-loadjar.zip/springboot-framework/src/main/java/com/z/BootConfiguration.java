package com.z;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.z.jarload.ShineyueLoadJar;
import com.z.jarload.ShineyueMappingRegulator;

@Configuration
public class BootConfiguration {
	
	/**
	 * 加载jar包的路径从application.properties里配置
	 */
	@Value("${framework.z.jarurl:?}")
	private String jarurl;
	/**
	 * 初始化动态注册mapping的bean
	 * @return
	 */
	@Bean(name="shineyueMappingRegulator")
	public ShineyueMappingRegulator shineyueMappingRegulator(){
		ShineyueMappingRegulator shineyueMappingRegulator=new ShineyueMappingRegulator();
		return shineyueMappingRegulator;
	}
	/**
	 * 初始化热加载jar包的bean
	 * @return
	 */
	@Bean(name="shineyueLoadJar")
	public ShineyueLoadJar shineyueLoadJar(){
		if(this.jarurl.equals("?")||this.jarurl.equals("")){
			return null;
		}
		ShineyueLoadJar shineyueLoadJar=new ShineyueLoadJar();
		shineyueLoadJar.setJarurl(this.jarurl);
		return shineyueLoadJar;
	}
}
